package com.LinkShortner.Link.shortner;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LinkShortnerApplicationTests {

	@Test
	void contextLoads() {
	}

}
